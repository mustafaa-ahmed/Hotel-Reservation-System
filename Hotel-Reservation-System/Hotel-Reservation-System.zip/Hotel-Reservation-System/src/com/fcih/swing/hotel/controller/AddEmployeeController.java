package com.fcih.swing.hotel.controller;

public interface AddEmployeeController {
    
}
