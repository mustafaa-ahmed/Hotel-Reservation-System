package com.fcih.swing.hotel.controller.impl;

import com.fcih.swing.hotel.controller.AddEmployeeController;

public class AddEmployeeControllerImpl implements AddEmployeeController{
    
}
