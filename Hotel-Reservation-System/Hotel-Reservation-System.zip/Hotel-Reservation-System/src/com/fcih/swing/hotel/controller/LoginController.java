package com.fcih.swing.hotel.controller;

public interface LoginController {
    public abstract boolean login(String code, String password);
}
