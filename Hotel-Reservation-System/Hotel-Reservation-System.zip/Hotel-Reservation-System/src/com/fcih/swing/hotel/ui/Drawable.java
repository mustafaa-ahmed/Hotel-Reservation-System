package com.fcih.swing.hotel.ui;

public interface Drawable {

    public abstract void initComponents();

    public abstract void draw();
}
